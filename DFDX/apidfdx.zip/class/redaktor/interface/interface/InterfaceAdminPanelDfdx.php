<?php
namespace class\redaktor\interface\interface;

// интерфейс для функций, реализующих работу административной панели CMS-DFDX
// interfejs dla funkcji realizujących pracę panelu administracyjnego CMS-DFDX
// interface for functions that implement the work of the CMS-DFDX administrative panel


interface InterfaceAdminPanelDfdx extends InterfaceWorkToMenu
{
    // Функция читает из таблицы имя последней редактируемой таблицы и помещает с поле меню административной панели
    // Funkcja odczytuje z tabeli nazwę ostatnio edytowanej tabeli i umieszcza ją w polu menu panelu administratora
    // The function reads the name of the last edited table from the table and places it in the admin panel menu field
    public function startMenuRedaktora();

    //Узнает у менюшки общий класс у всех кнопок или у каждой кнопки свой класс
    //Rozpoznaje ogólną klasę menu dla wszystkich przycisków lub każdy przycisk ma swoją własną klasę
    //Recognizes the general class of the menu for all buttons or each button has its own class
    public function kakovClass($nameMenu);
}
