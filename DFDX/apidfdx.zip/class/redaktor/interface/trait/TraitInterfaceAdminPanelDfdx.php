<?php
namespace class\redaktor\interface\trait;

trait TraitInterfaceAdminPanelDfdx
{
    public function kakovClass($nameMenu) 
    {
      $zapros="SELECT CLASS FROM tablica_tablic WHERE NAME='".$nameMenu."'";
      $rez=$this->zaprosSQL($zapros);
      $stroka=mysqli_fetch_array($rez);
      if (!isset($stroka)) return false;
      if ($stroka[0]==0) return false;
      if ($stroka[0]==1) return true;
    }

    public function startMenuRedaktora()
    {
        $zapros="SELECT * FROM nastrolkiredaktora WHERE 1";
        $rez=$this->zaprosSQL($zapros);
        $stroka=mysqli_fetch_assoc($rez);
        $poslednijZapros=$stroka['imiePosTabl'];
        $_SESSION['nameTablice']=$poslednijZapros;
        if (!$this->searcNameTablic($poslednijZapros)) $poslednijZapros="";
        echo '<h6 class="mesage">*поле слева предназначено для имени таблицы</h6>';
        echo '<h6 class="error">**Внимание!! Не использовать заглавные буквы в названии таблицы</h6>';
        $this->__unserialize(array('menu7','redaktor_nastr7','redaktor.php',$poslednijZapros,'не важно','не важно','не важно','не важно','не важно','не важно','не важно','не важно','не важно','не важно'));
     }
}
