<?php
namespace class\redaktor\interface\trait;

trait TraitInterfaceWorkToBd
{

  public function connectToBd()
  {
      $fd = fopen($this->searcNamePath('tmp/initBD.ini'), 'r') or die("не удалось открыть файл");
      $this->host=stristr(fgets($fd),';',true); 
      $this->loginBD=stristr(fgets($fd),';',true); 
      $this->parol=stristr(fgets($fd),';',true); 
      $this->nameBD=stristr(fgets($fd),';',true); 
      $this->site=stristr(fgets($fd),';',true); 
      fclose($fd);
      $this->con = mysqli_connect($this->initBdHost(),$this->initBdLogin(),$this->initBdParol(),$this->initBdNameBD()) OR die ('ошибка подключения БД');   //подключить бд        mysqli_set_charset ( $con , "utf8" ) ;
  }

  public function tableValidationCMS()
      {
            ///////////////////////// Проверка таблиц движка
            // ------------------------Расшифровка позиций в таблице настроек----------------------
            // id=1 - Сюда записан признак включить или выключить форму сбора нецензурных слов от пользователей
            //проверка существует ли таблица настроек
            if (!$this->searcNameTablic('tablica_nastroer_dvigka_int'))
              $this->zaprosSQL("CREATE TABLE tablica_nastroer_dvigka_int(id INT, nastr INT)");
            ////////////////////////////////Восстановление таблицы tablica_nastroer_dvigka_int
            $zapros="SELECT nastr FROM tablica_nastroer_dvigka_int WHERE id=1"; //настройка показа формы сбора данных
            $rez=$this->zaprosSQL($zapros);
            if ($rez) $stroka=mysqli_fetch_array($rez);
            if (is_null($stroka[0])) 
               $this->zaprosSQL("INSERT INTO tablica_nastroer_dvigka_int(id, nastr) VALUES (1,0)");
            /////////////////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////////////// таблица блокировки пользователей для добавления мата blocked_list_dobavit_mat////////////////
            //проверка существует ли таблица блокировки пользователей для добавления мата blocked_list_dobavit_mat
            if (!$this->searcNameTablic('blocked_list_dobavit_mat'))
              $this->zaprosSQL("CREATE TABLE blocked_list_dobavit_mat(id INT, login VARCHAR(50))");

            // проверка таблицы status_klienta
            if (!$this->searcNameTablic('status_klienta')) {
                $zapros="CREATE TABLE status_klienta(login VARCHAR(30), parol VARCHAR(30), mail VARCHAR(50), status INT , time INT)";
                $this->zaprosSQL($zapros);
               }

            //Проверка существования таблицы type_menu_po_imeni
            if (!$this->searcNameTablic('type_menu_po_imeni')) {  // Проверяем есть ли таблица с названия-типами меню
              $zapros="CREATE TABLE type_menu_po_imeni(
                                                        name_menu    VARCHAR (100),
                                                        type_menu    INT 
                                                      )  ";
              $this->zaprosSQL($zapros);
            } 
      }

  public function createTab(...$parametr) //функция проверяет есть ли таблица и если нет, то создает её
  {
   $nametablice='';
   $masN=array();
   $masT=array();
   $masS=array();
   $prosmotr=false;
   $zapros1='Таблица уже существует!';
   $zapros2='Стартовое значение уже задано!';
   $i=0;
   $ii=0;
   $iii=0;
   foreach($parametr as $value) {
       if (stripos('sss'.$value,'name=')) {
           $nametablice=preg_replace('/name=/','',$value);
           $nametablice=mb_strtolower($nametablice);
       }
       if (stripos('sss'.$value,'просмотр'))
           $prosmotr=true;
       if (stripos('sss'.$value,'poleN='))
           $masN[$i++]=preg_replace('/poleN=/','',$value);
       if (stripos('sss'.$value,'poleT='))
           $masT[$ii++]=preg_replace('/poleT=/','',$value);
       if (stripos('sss'.$value,'poleS='))
           $masS[$iii++]=preg_replace('/poleS=/','',$value);
       if ($value=='help' || $value=='Помощь') {
           echo '<p>Функция проверяет существует ли таблица, если нет, то создает её и присваивает начальные значения</p>';
           echo '<p>Обязательный параметр "name=имя таблица"</p>';
           echo '<p>Имя поля задается параметром "poleN=имя поля"</p>';
           echo '<p>Тип поля задается параметром "poleT=тип поля"</p>';
           echo '<p>Первичное значение поля задается параметром "poleS=значение"</p>';
           echo '<p>Число полей poleN,poleT,poleS должно быть одинаково.</p>';
           echo '<p>Если необходимо только посмотреть запроссы, то добавляем параметр "просмотр"</p>';
           echo '<p></p>';
           echo '<p></p>';
           echo '<p></p>';
           echo '<p></p>';
         } 
     }
   if ($nametablice=='' || $i!=$ii || $ii!=$iii) {
       echo 'Не корректное имя таблицы';
       return false;
     } //если забыли задать имя таблицы, то выходим из функции

   if (!$this->searcNameTablic($nametablice)) {
      $zapros="CREATE TABLE ".$nametablice.' (';
      $z='';
      for($j=0; $j<$i; $j++) {
          if ($j+1<$i)
             $z=$z.$masN[$j].' '.$masT[$j].', ';
          else $z=$z.$masN[$j].' '.$masT[$j];
        }
     $zapros=$zapros.$z.')';
     $zapros1=$zapros;
     if (!$prosmotr)
        $this->zaprosSQL($zapros);
     } 
 
 if (!$this->kolVoZapisTablice($nametablice)>0) {
     $zapros="INSERT INTO ".$nametablice.' (';
     $z='';
     $z1='';

     for($j=0; $j<$i; $j++) {
       if ($j+1<$i)
           $z=$z.$masN[$j].', ';
       else 
           $z=$z.$masN[$j];
       $znak='';

       if (stripos('sss'.$masT[$j],'VARCHAR') 
        || stripos('sss'.$masT[$j],'varchar')
         || ($masT[$j]=='TEXT' || $masT[$j]=='text')
           || ($masT[$j]=='DATE' || $masT[$j]=='date')
             || ($masT[$j]=='DATETIME' || $masT[$j]=='datetime')
               || ($masT[$j]=='TIMESTAMP' || $masT[$j]=='timestamp')
                 || ($masT[$j]=='TIME' || $masT[$j]=='time')
                   || ($masT[$j]=='CHAR' || $masT[$j]=='char')
                     || ($masT[$j]=='TINYTEXT' || $masT[$j]=='tinytext')
                       || ($masT[$j]=='MEDIUMTEXT' || $masT[$j]=='mediumtext')
                         || ($masT[$j]=='LONGTEXT' || $masT[$j]=='longtext')
                           || ($masT[$j]=='BINARY' || $masT[$j]=='binary')
                             || ($masT[$j]=='VARBINARY' || $masT[$j]=='varbinary')
                               || ($masT[$j]=='TINYBLOB' || $masT[$j]=='tinyblob')
                                 || ($masT[$j]=='MEDIUMBLOB' || $masT[$j]=='mediumblob')
                                   || ($masT[$j]=='LONGBLOB' || $masT[$j]=='longblob')
                                     || ($masT[$j]=='BLOB' || $masT[$j]=='blob')
                                       || ($masT[$j]=='ENUM' || $masT[$j]=='enum')
                                         || ($masT[$j]=='SET' || $masT[$j]=='set')
        ) $znak="'";
         
       if ($j+1<$i)
           $z1=$z1.$znak.$masS[$j].$znak.',';
       else 
           $z1=$z1.$znak.$masS[$j].$znak;
      }
      $zapros=$zapros.$z.') VALUES ('.$z1.')';
      $zapros2=$zapros;
      if (!$prosmotr)
       $this->zaprosSQL($zapros);
   } 
   if ($prosmotr)  //режим просмотра запроссов
     echo '<p>Запрос для создания таблицы: '.$zapros1.'</p><p>Запрос для первой строки: '.$zapros2.'</p>';
  }
  
     public function kolVoStolbovTablice($nameTablice)  
     {
         $zapros="SELECT MAX(ORDINAL_POSITION) FROM INFORMATION_SCHEMA.columns WHERE TABLE_NAME='".$nameTablice."'";
         $query=$this->zaprosSQL($zapros);   
         $viv=mysqli_fetch_array($query);
         return $viv[0];
      }
     public function kolVoZapisTablice($nameTablice)  
     {
         if ($this->searcNameTablic($nameTablice)) {
             $zapros="SELECT COUNT(1) FROM ".$nameTablice;
             $rez=$this->zaprosSQL($zapros);
             $viv=mysqli_fetch_array($rez);
             return $viv[0];
          } else return 0;
     }

     public function tablicaDlaMenu($nameTablice)
     {
         $boolRez=false;
         $zapros="SELECT ID FROM tablica_tablic WHERE NAME='".$nameTablice."'";
         $rez=$this->zaprosSQL($zapros);
         if ($this->notFalseAndNULL($rez)!==true) echo 'Проблема с таблицей "tablica_tablic"';
         if ($this->notFalseAndNULL($rez)) $stroka=mysqli_fetch_array($rez);
         if ($this->notFalseAndNULL($stroka))   
         if ($stroka[0]>-1) $boolRez=true;
         return $boolRez; 
      }
      
     public function zaprosSQL($zapros)
     {
         $statistikTrueFalseRez=mysqli_query($this->con,'SELECT statik_true FROM statistik_dfdx WHERE 1');
         $statistikTrueFalse=mysqli_fetch_assoc($statistikTrueFalseRez);
         if ($statistikTrueFalse['statik_true']==1) {
             $statistikTrueFalseRez=mysqli_query($this->con,'SELECT n_zapros FROM statistik_dfdx WHERE 1');
             $statistik_n_zapros=mysqli_fetch_assoc($statistikTrueFalseRez);
             $statistik_n_zapros['n_zapros']++;
             mysqli_query($this->con,'UPDATE statistik_dfdx SET n_zapros='.$statistik_n_zapros['n_zapros'].' WHERE 1');
             mysqli_query($this->con,'UPDATE statistik_dfdx SET d_zapros="'.date("y.m.d").'" WHERE 1');
          }
         $rez=mysqli_query($this->con,$zapros);
         return $rez;
     }

     public function killZapisTablicy($nameTablice,$were) 
     {
        $zapros="DELETE FROM ".$nameTablice." ".$were;
        $rez=$this->zaprosSQL($zapros);
     }

     public function maxIdLubojTablicy($nameTablice)  // поиск максимального ID таблицы +1
     {
         $zapros="SELECT MAX(id) FROM ".$nameTablice;
         $rez=$this->zaprosSQL($zapros);
         if ($rez===false) return -1;
         $stroka=mysqli_fetch_array($rez);
         if (is_null($stroka[0])) $stroka[0]=-1;
         $rezId=$stroka[0]+1;
         return $rezId;
      }

      public function clearTab($nameTablicy)
          {
              $zapros="TRUNCATE TABLE ".$nameTablicy;
              $rez=$this->zaprosSQL($zapros);
          }

      public function killTabEtap1($nameTablicy)
      {      
          if ($this->searcNameTablic($nameTablicy)) {
              echo '<h4>Внимание!! Попытка удалить таблицу '.$nameTablicy.'</h4>'; 
                  echo '<div class="container">';
                      echo '<div class="row">';
                          echo '<form method="POST" action="redaktor.php">';
                              echo '<input class="btn btn-primary buttonStartNastrRedaktor" type="submit" value="'.$this->zapretUdaleniaTablicy($nameTablicy).'" name="killTabOk">';
                              echo '<input class="btn btn-primary buttonStartNastrRedaktor" type="submit" value="Отмена" name="killTabCancel">';
                          echo '</form>';
                      echo '</div>';
                  echo '</div>';
            } else 
            okCansel('Такой таблицы нет и не важно на что нажать:). Пока-пока...','poka_poka','divTabUniwJestUge','pTabUniwJestUge','buttonTabUniwJestUge');
       }

      public function killTab($nameTablicy)
      {
          $zapros="DROP TABLE ".$_SESSION['nameTablice'];
          $rez=$this->zaprosSQL($zapros);
      }

      public function killTab2($nameTablicy)
      {
          $zapros="DROP TABLE ".$nameTablicy;
          $rez=$this->zaprosSQL($zapros);
      }
      public function searcNameTablic($nameTablicy)  
      {
          $result=false;
          $zapros="SHOW TABLES";
          $rez=$this->zaprosSQL($zapros);
          while (!is_null($stroka=(mysqli_fetch_array($rez))))
              if ($stroka[0]==$nameTablicy)   
                  $result=true;           
          return $result;
       }
      public function id_tab_gl_searc($nameTablicy)
      {
         $zapros="select * from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='".$nameTablicy."'";
         $stroka='';
         $rez=$this->zaprosSQL($zapros);
         if ($this->notFalseAndNULL($rez)) {
               $stroka=(mysqli_fetch_assoc($rez));
               return false;
             }
         if ($stroka['COLUMN_NAME']=='id_tab_gl') return true;
         return false;
      }

      public function radioAndChekboxSearc($nameTablicy)
        {
            $zapros="select  from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME='".$nameTablicy."'";
            $rez=$this->zaprosSQL($zapros);
            $vozvrat=false;
            $str=$this->kolVoZapisTablice($nameTablice);
            while (!is_null($stroka=(mysqli_fetch_assoc($rez))))
               if ($stroka['radio'] || $stroka['checkbox']) {
                  $vozvrat=true;
                  break;
              }
            return $vozvrat;
        }

     public function zapretUdaleniaTablicy($nameTablicy)  
        {
           if ($nameTablicy=='menu_parametr_tab') return 'Невозможно удалить';
           if ($nameTablicy=='nastrolkiredaktora') return 'Невозможно удалить';
           if ($nameTablicy=='redaktor_down') return 'Невозможно удалить';
           if ($nameTablicy=='redaktor_nastr7') return 'Невозможно удалить';
           if ($nameTablicy=='redaktor_up') return 'Невозможно удалить';
           if ($nameTablicy=='tablica_tablic') return 'Невозможно удалить';
           if ($nameTablicy=='login') return 'Невозможно удалить';
           if ($nameTablicy=='registracia') return 'Невозможно удалить';//
           if ($nameTablicy=='podtverdit') return 'Невозможно удалить';
           if ($nameTablicy=='status_klienta') return 'Невозможно удалить';
           if ($nameTablicy=='type_menu_po_imeni') return 'Невозможно удалить';
           if ($nameTablicy=='redakt_profil') return 'Невозможно удалить';
           if ($nameTablicy=='redakt_profil_tegi') return 'Невозможно удалить';
           if ($nameTablicy=='maty') return 'Невозможно удалить';
           if ($nameTablicy=='menu_maty') return 'Невозможно удалить';
           if ($nameTablicy=='mat_ot_polzovatelej') return 'Невозможно удалить';
           if ($nameTablicy=='nie_maty') return 'Невозможно удалить';
           if ($nameTablicy=='tablica_nastroer_dvigka_int') return 'Невозможно удалить';  
           if ($nameTablicy=='dla_statusob_123') return 'Невозможно удалить';
           return 'Согласен удалить';
       }
  
    public function siearcSlova($nameTablice,$stolb,$slovo)
      {
        $zapros="SELECT ".$stolb." FROM ".$nameTablice." WHERE ".$stolb."='".$slovo."'";
        $rez=$this->zaprosSQL($zapros);
        if ($rez===false) return false;
        $stroka=mysqli_fetch_array($rez);
        if (is_null($stroka)) return false;
        $strr='--'.$stroka[0];
        $strVhod=stripos( $strr ,$slovo);
        if ($strVhod>1) return true;
        return false;
      }

    public function searcIdPoUsloviu($nameTablicy,$usl1,$usl2,$usl3,$usl4,$usl5)  
    {
      $zapros="SELECT MAX(id) FROM ".$nameTablicy;
      if ($usl1!="") $zapros=$zapros.' WHERE '.$usl1;
      if ($usl2!="") $zapros=$zapros.' AND '.$usl2;
      if ($usl3!="") $zapros=$zapros.' AND '.$usl3;
      if ($usl4!="") $zapros=$zapros.' AND '.$usl4;
      if ($usl5!="") $zapros=$zapros.' AND '.$usl5;
      $rez=$this->zaprosSQL($zapros);
      if (!$rez) return 0;
      $stroka=mysqli_fetch_array($rez);
      if (is_null($stroka)) return 0;
      if ($stroka[0]=='')   return 0;
      if ($stroka)  return $stroka[0];
      return 0;
    }

    public function initBdHost()
    {
      return $this->host;
    }

    public function initBdLogin()
    {
      return $this->loginBD;
    }

    public function initBdParol()
    {
      return $this->parol;
    }

    public function initBdNameBD()
    {
      return $this->nameBD;
    }

    public function initsite()
    {
      return $this->site;
    } 

    public function checkedStatus($pole,$str,$status,$nameTable)
    {
      $zapros="SELECT status FROM ".$nameTable."_status WHERE stolb=".$pole." AND str=".$str;
      $rez=$this->zaprosSQL($zapros);
      if ($rez===false) return ' ';
      $stroka=mysqli_fetch_array($rez);
      if ($stroka===false) return ' ';
      if (stripos($stroka['0'],$status)!==false) return 'checked';
      $rez=$this->zaprosSQL($zapros);
      $stroka=mysqli_fetch_array($rez);
      return ' ';
    }

    public function naGlavnuStranicu()
    {
      exit("<meta http-equiv='refresh' content='0; url= ".$this->initsite()."'>");
    }

    public function tutObnovit()
    {
      exit("<meta http-equiv='refresh' content='0; url= 'redaktor.php'>");
    }

    public function nameGlawnogoSite()
    {
      return $this->initsite();
    }
}
