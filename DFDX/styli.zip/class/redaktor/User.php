<?php

namespace class\redaktor;

class User implements interface\interface\InterfaceWorkToBd
{

use TraiteInterfaceWorkToBd


} // конец класса
