<?php
declare(strict_types=1);

namespace class\redaktor;

include 'class.php';

$www = new User();
