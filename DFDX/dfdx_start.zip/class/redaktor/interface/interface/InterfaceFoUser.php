<?php
namespace class\redaktor\interface\interface;

//Интерфейс работы с пользователями
//Interfejs użytkownika
//User Interface

interface InterfaceFoUser
{
   // Преобразуем номер статуса в его значение
   // Konwertuj numer statusu na jego wartość
   // Convert the status number to its value
   public function statusNumerSlovo($status);
}
