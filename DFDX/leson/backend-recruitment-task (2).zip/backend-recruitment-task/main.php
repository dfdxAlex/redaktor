<?php


// автозагрузка движка dfdx для использования библиотек, после отладки удалить
require "../../class.php";

// подключение своего автозагрузчика
require "class.php";

// подключение заголовка HTML страницы включая открытый тег body
echo new \Object\HtmlHead('assets/css/styli.css','JSON');
// <body>

// удалить
echo'
<br>
<form action="main.php" method="post">
<input type="submit" name="restart" value="restart">
</form><br>
';

// создаем объект для работы с удалениями данных из таблицы
$jsonMas = new \Object\CreateTable();

// возвращает в переменную $nomerKill ID номер нажатой кнопки УДАЛЕНИЯ
$nomerKill=new \ValueObject\NomerButton();

// удаляем элемент массива, указанный в переменной $nomerKill, из файла json
$killUser = new \Object\KillUser($jsonMas,$nomerKill);


// создаем объект для работы с таблицами
$jsonMas = new \Object\CreateTable();

echo '<p>Zatwierdź zmianę 1</p>';
// содаем таблицу без кнопок Удалить (нет входного параметра, либо есть, но false)
$jsonMas->createTab();

echo '<div class="zmiane"><p>Zatwierdź zmianę 2</p></div>';
// создаем таблицу с кнопками Удалить (есть входной параметр true)
$jsonMas->createTab(true);

// удалить
echo'
<br>
<form action="main.php" method="post">
<input type="submit" name="restart" value="restart">
</form><br>
';


// ставим форму для добавления клиента
echo new \Object\FormAdd(new \ValueObject\Geo());

// показать свободный id
echo  new \ValueObject\ToId(new \Object\CreateTable()).'<br>';

// показать поле Name 
echo  new \ValueObject\ToName().'<br>';

// показать поле ToUserName ToEmail
echo  new \ValueObject\ToUserName().'<br>';

// показать поле ToEmail
echo  new \ValueObject\ToEmail().'<br>';

// показать поле ToPhone
echo  new \ValueObject\ToPhone().'<br>';

// показать поле ToWebsite
echo  new \ValueObject\ToWebsite().'<br>';

// показать поле ToSuite
echo  new \ValueObject\ToSuite().'<br>';

// показать поле ToStreet
echo  new \ValueObject\ToStreet().'<br>';

// показать поле ToCity
echo  new \ValueObject\ToCity().'<br>';

// показать поле ToZip
echo  new \ValueObject\ToZip().'<br>';

// показать поле ToNameCompany
echo  new \ValueObject\ToNameCompany().'<br>';

// показать поле ToCompanySlogan
echo  new \ValueObject\ToCompanySlogan().'<br>';

// показать поле ToCompanyBS
echo  new \ValueObject\ToCompanyBS().'<br>';

// показать поле ToGeoLat
echo  new \ValueObject\ToGeoLat(new \ValueObject\Geo()).'<br>';

// показать поле ToGeoLon
echo  new \ValueObject\ToGeoLon(new \ValueObject\Geo()).'<br>';


// подключение библиотеки движка dfdx для использования функций отладки. После отладки удалить
//$jsonMas = new \Object\CreateTable();








$qqq = new \class\redaktor\instrument();

// функция просмотра содержимого массива, после отладки удалить
$qqq->printMas($jsonMas->getFileJsonMas());





// </body>
// Закрытие документа html
echo new \Object\HtmlFutter();


