<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToName
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['name']!='' && $_POST['name']!="Name")
                return $_POST['name'];
        return 'null';
    }
}
