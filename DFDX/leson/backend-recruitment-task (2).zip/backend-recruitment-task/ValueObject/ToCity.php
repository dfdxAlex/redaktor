<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToCity
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['city']!='' && $_POST['city']!="city")
                return $_POST['city'];
        return 'null';
    }
}
