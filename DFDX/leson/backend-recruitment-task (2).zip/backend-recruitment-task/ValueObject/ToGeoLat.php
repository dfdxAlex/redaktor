<?php
namespace ValueObject;

// объект возвращает geoLat(координату геолокации) пользователя или строку null
class ToGeoLat
{
    public function __construct(\ValueObject\Geo $geo)
    {
        $this->geoLat=$geo->getGeoParam('lat');
    }

    public function __toString()
    {
            if ($this->geoLat!='')
                return $this->geoLat;
        return 'null';
    }
}


