<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToZip
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['zip']!='' && $_POST['zip']!="Zip code")
                return $_POST['zip'];
        return 'null';
    }
}
