<?php
namespace ValueObject;

// объект возвращает вебсайт пользователя или строку null
class ToWebsite
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['website']!='') {
                $res1 = preg_match('/www\.[^\..]*\./',$_POST['website']);
                if (($res1)>0)
                    return $_POST['website'];
            }
        return 'null';
    }
}
