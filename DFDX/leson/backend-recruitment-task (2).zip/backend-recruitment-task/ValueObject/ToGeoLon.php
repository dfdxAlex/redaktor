<?php
namespace ValueObject;

// объект возвращает geoLon(координату геолокации) пользователя или строку null
class ToGeoLon
{
    public function __construct(\ValueObject\Geo $geo)
    {
        $this->geoLon=$geo->getGeoParam('lon');
    }

    public function __toString()
    {
            if ($this->geoLon!='')
                return $this->geoLon;
        return 'null';
    }
}


