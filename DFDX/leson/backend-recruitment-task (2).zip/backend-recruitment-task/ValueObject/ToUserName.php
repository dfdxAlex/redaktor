<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToUserName
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['userName']!='' && $_POST['userName']!="UserName")
                return $_POST['userName'];
        return 'null';
    }
}
