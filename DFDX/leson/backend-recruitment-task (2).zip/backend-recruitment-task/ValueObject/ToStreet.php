<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToStreet
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['street']!='' && $_POST['street']!="Street")
                return $_POST['street'];
        return 'null';
    }
}
