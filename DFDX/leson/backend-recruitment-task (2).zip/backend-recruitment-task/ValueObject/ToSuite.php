<?php
namespace ValueObject;

// объект возвращает имя пользователя или строку null
class ToSuite
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['suite']!='' && $_POST['suite']!="Suite")
                return $_POST['suite'];
        return 'null';
    }
}
