<?php
namespace ValueObject;

// объект возвращает BS компании пользователя или строку null
class ToCompanyBS
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['Company_BS']!='' && $_POST['Company_BS']!="Company BS")
                return $_POST['Company_BS'];
        return 'null';
    }
}


