<?php
namespace ValueObject;

// объект возвращает слоган компании пользователя или строку null
class ToCompanySlogan
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['Company_slogan']!='' && $_POST['Company_slogan']!="Company slogan")
                return $_POST['Company_slogan'];
        return 'null';
    }
}



