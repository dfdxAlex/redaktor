<?php
namespace ValueObject;

// объект возвращает имя города пользователя или строку null
class ToNameCompany
{
    public function __construct()
    {
    }

    public function __toString()
    {
        if (isset($_POST['Save']))
            if ($_POST['name_company']!='' && $_POST['name_company']!="Name company")
                return $_POST['name_company'];
        return 'null';
    }
}
