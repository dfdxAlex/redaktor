<?php
namespace ValueObject;

class Geo
{
    private $status;
    private $country;
    private $countryCode;
    private $region;
    private $regionName;
    private $city;
    private $zip;
    private $lat;
    private $lon;
    private $timezone;
    private $isp;
    private $org;
    private $as;
    private $query;

    public function __construct()
    {
        $ip = $_SERVER['REMOTE_ADDR'];
        echo $ip;




        $query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip.'?lang=en'));
        if($query && $query['status'] == 'success') {
            echo 'Привет, посетитель из '.$query['country'].', '.$query['city'].'!';
            } else {
            echo 'Не удалось определить локацию<br>';
        }
    }

}
