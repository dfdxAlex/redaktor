<?php
namespace Object;

// класс создает форму для заполнение данных для нового пользователя
class FormAdd
{
    public function __construct()
    {

    }

    public function __toString()
    {
        return ' 
                 <section class="container-fluid">
                 <div class="form-add-div">
                 <form action="#" method="post" class="form-add-form">
                   <div class="row">
                     <div class="col-6">
                         <h6>Wpisz swoje imię</h6>
                         <input type="text" name="name" placeholder="Name">
                     </div>
                     <div class="col-6">
                         <h6>Wpisz nazwę użytkownika</h6>
                         <input type="text" name="userName" placeholder="UserName">
                     </div>
                   </div>
                 </form>
                 </div>
                 </section>
        ';
    }
}
