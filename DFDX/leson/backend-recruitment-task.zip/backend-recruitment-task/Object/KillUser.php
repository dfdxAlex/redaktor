<?php
namespace Object;

// класс удаляет запись в файле json перезаписывая его
// параметр CreateTable $ct, нужен для использывания некоторых методов от класса CreateTable
// параметр string $id определяет ID той записи, которую нужно удалить
class KillUser
{
    private $testStrokaJson;
    public function __construct(CreateTable $ct, string $id)
    {
        // преобразовать стринг в инт
        $killId=(int)$id;

        // вернуть декодированный массив из файла json
        if ($killId>0) {
            $masJson=$ct->getFileJsonMas();

            foreach ($masJson as $key=>$value) {
                if ($value['id']==$killId) {
                    unset($masJson[$key]);
                    break;
                }
            }
        } else return;

        $strokaJson=json_encode($masJson,JSON_PRESERVE_ZERO_FRACTION);

        file_put_contents("dataset\users.json",$strokaJson);

        // переменна необходима для тестирования и выводится черех магический метод toString
        $this->testStrokaJson=$strokaJson;
    }

    public function __toString()
    {
        // переменна необходима для тестирования и выводится черех магический метод toString
        return $this->testStrokaJson;
    }
}
