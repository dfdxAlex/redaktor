<?php
namespace Object;

// класс создает форму для заполнение данных для нового пользователя
class FormAdd
{
    public function __construct()
    {

    }

    public function __toString()
    {
        return ' 
                 <section class="container-fluid">
                 <div class="form-add-div">
                 <form action="#" method="post" class="form-add-form">

                     <div class="row input-text">
                       <div class="col-6">
                       <div class="row">
                         <div class="col-6">
                           <h6>Wpisz swoje imię</h6>
                           <input type="text" name="name" placeholder="Name">
                         </div>
                         <div class="col-6">
                           <h6>Wpisz nazwę użytkownika</h6>
                           <input type="text" name="userName" placeholder="UserName">
                         </div>
                           </div>
                       </div>
                     </div>

                     <div class="row input-text">
                     <div class="col-6">
                         <div class="row">
                           <div class="col-6">
                             <h6>Twój email</h6>
                             <input type="text" name="email" placeholder="email">
                           </div>
                           <div class="col-6">
                             <h6>Twój numer telefonu</h6>
                             <input type="text" name="phone" placeholder="phone">
                           </div>
                         </div>
                     </div>
                     <div class="col-6">
                         <h6>Twoja strona internetowa</h6>
                         <input type="text" name="website" placeholder="website">
                     </div>
                     </div>


                 </form>
                 </div>
                 </section>
        ';
    }
}
