<?php


// автозагрузка движка dfdx для использования библиотек, после отладки удалить
require "../../class.php";

// подключение своего автозагрузчика
require "class.php";

// подключение заголовка HTML страницы включая открытый тег body
echo new \Object\HtmlHead('assets/css/styli.css','JSON');
// <body>

// удалить
echo'
<br>
<form action="main.php" method="post">
<input type="submit" name="restart" value="restart">
</form><br>
';

// создаем объект для работы с удалениями данных из таблицы
$jsonMas = new \Object\CreateTable();

// возвращает в переменную $nomerKill ID номер нажатой кнопки УДАЛЕНИЯ
$nomerKill=new \ValueObject\NomerButton();

// удаляем элемент массива, указанный в переменной $nomerKill, из файла json
$killUser = new \Object\KillUser($jsonMas,$nomerKill);


// создаем объект для работы с таблицами
$jsonMas = new \Object\CreateTable();

echo '<p>Zatwierdź zmianę 1</p>';
// содаем таблицу без кнопок Удалить (нет входного параметра, либо есть, но false)
$jsonMas->createTab();

echo '<div class="zmiane"><p>Zatwierdź zmianę 2</p></div>';
// создаем таблицу с кнопками Удалить (есть входной параметр true)
$jsonMas->createTab(true);

// удалить
echo'
<br>
<form action="main.php" method="post">
<input type="submit" name="restart" value="restart">
</form><br>
';

// ставим форму для добавления клиента
echo new \Object\FormAdd();

$sss = new \ValueObject\Geo();

// подключение библиотеки движка dfdx для использования функций отладки. После отладки удалить
$jsonMas = new \Object\CreateTable();

$qqq = new \class\redaktor\instrument();

// функция просмотра содержимого массива, после отладки удалить
$qqq->printMas($jsonMas->getFileJsonMas());





// </body>
// Закрытие документа html
echo new \Object\HtmlFutter();


