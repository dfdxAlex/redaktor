<?php
namespace class\redaktor;

trait TraitInstrument
{
    public function traitEcho()
    {
        return 'traitEchoInstrument';
    }
}
