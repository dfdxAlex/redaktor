<?php
namespace class\redaktor\interface\interface;

interface InterfaceButton
{
    
}
