<?php
namespace class\redaktor\interface\trait;

trait TraitInterfaceButton
{
    
}
