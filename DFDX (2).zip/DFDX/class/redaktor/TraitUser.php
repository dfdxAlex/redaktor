<?php
namespace class\redaktor;

trait TraitUser
{
    public function traitEcho()
    {
        return 'traitEchoUser';
    }
}
