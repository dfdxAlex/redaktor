<?php
namespace class\nonBD;

class Button implements \class\nonBD\interface\InterfaceButton
{
    use \class\redaktor\interface\trait\TraitInterfaceButton;
    public function __construct()
    {
        
    }
}
