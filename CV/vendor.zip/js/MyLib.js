function writeHtml(str)
{
    document.write(str);
}


